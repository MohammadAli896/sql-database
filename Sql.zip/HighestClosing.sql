SELECT
    oc.Date,
    oc.Close
FROM
    Open_Close oc
WHERE
    oc.Close = (SELECT MAX(Close) FROM Open_Close);