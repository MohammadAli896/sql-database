CREATE TABLE Company (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Ticker VARCHAR(10) NOT NULL,
    CompanyName VARCHAR(255) NOT NULL
);

CREATE TABLE High_Low (
    stock_Id INT,
    Date DATE,
    High DECIMAL(10, 2),
    Low DECIMAL(10, 2),
    FOREIGN KEY (stock_Id) REFERENCES Company(Id)
);

CREATE TABLE Open_Close (
    stock_Id INT,
    Date DATE,
    Open DECIMAL(10, 2),
    Close DECIMAL(10, 2),
    AdjClose DECIMAL(10, 2),
    FOREIGN KEY (stock_Id) REFERENCES Company(Id)
);

CREATE TABLE Volume (
    stock_Id INT,
    Date DATE,
    Volume INT,
    FOREIGN KEY (stock_Id) REFERENCES Company(Id)
);
