SELECT
    v.Date,
    v.Volume
FROM
    Volume v
WHERE
    v.Volume = (SELECT MIN(Volume) FROM Volume);