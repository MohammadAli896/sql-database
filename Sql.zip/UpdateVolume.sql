UPDATE Volume
SET Volume = 1
WHERE Date = '2016-12-15';