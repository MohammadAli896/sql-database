SELECT
    c.Ticker,
    c.CompanyName,
    oc.Date,
    oc.Open,
    hl.High,
    hl.Low,
    oc.Close,
    oc.AdjClose,
    v.Volume
FROM
    Company c
JOIN
    Open_Close oc ON c.Id = oc.stock_Id
JOIN
    High_Low hl ON oc.stock_Id = hl.stock_Id AND oc.Date = hl.Date
JOIN
    Volume v ON oc.stock_Id = v.stock_Id AND oc.Date = v.Date
ORDER BY
    oc.Date;