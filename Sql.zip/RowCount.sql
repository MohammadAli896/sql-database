SELECT COUNT(*) AS High_Low_Count FROM High_Low;

SELECT COUNT(*) AS Open_Close_Count FROM Open_Close;

SELECT COUNT(*) AS Volume_Count FROM Volume;